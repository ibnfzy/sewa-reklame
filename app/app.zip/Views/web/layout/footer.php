<div class="footer">
  <div class="container">
    <div class="row">
      <div class="col-md-3">
        <ul class="footer_box">
          <h4>Fast Link</h4>
          <li><a href="<?= base_url('AdminPanel') ?>">Login Admin</a></li>
        </ul>
      </div>
      <div class="col-md-8">
        <ul class="footer_box">
          <h4>Klien Kerja Sama</h4>
          <ul class="social">
            <img width="100" src="<?= base_url('yamaha.png'); ?>" alt="">
            <img width="100" src="<?= base_url('bri.png'); ?>" alt="">
            <img width="100" src="<?= base_url('phd.png'); ?>" alt="">
            <img width="100" src="<?= base_url('tanjung.png'); ?>" alt="">
            <img width="100" src="<?= base_url('nestle.png'); ?>" alt="">
            <img width="100" src="<?= base_url('halo.png'); ?>" alt="">
          </ul>

        </ul>
      </div>
    </div>
  </div>
</div>