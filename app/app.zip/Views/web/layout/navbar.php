<div class="header">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="header-left">
          <div class="logo">
            <!-- <a href="index.html"><img src="<?= base_url('') ?>images/logo.png" alt="" /></a> -->
          </div>
          <div class="menu">
            <a class="toggleMenu" href="#"><img src="<?= base_url('') ?>images/nav.png" alt="" /></a>
            <ul class="nav" id="nav">
              <li><a href="<?= base_url('') ?>">HOME</a></li>
              <li><a href="<?= base_url('Lokasi') ?>">Katalog Lokasi Reklame</a></li>
              <li><a href="<?= base_url('Panel') ?>">Pelanggan Panel</a></li>
              <div class="clear"></div>
            </ul>
            <script type="text/javascript" src="<?= base_url('') ?>js/responsive-nav.js"></script>
          </div>
          <div class="clear"></div>
        </div>
        <div class="header_right">
          <!-- start search-->
          <div class="clear"></div>
        </div>
      </div>
    </div>
  </div>
</div>